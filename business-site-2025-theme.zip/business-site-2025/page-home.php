<?php
/* Template Name: Home */
get_header(); ?>
<div class="section">
<h1>Welcome to Our Business</h1>
<p>We help businesses grow online.</p>
</div>
<?php get_footer(); ?>
