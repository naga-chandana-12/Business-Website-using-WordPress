<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body>
<header>
  <a href="<?php echo site_url(); ?>">Home</a>
  <a href="<?php echo site_url('/about'); ?>">About</a>
  <a href="<?php echo site_url('/services'); ?>">Services</a>
  <a href="<?php echo site_url('/contact'); ?>">Contact</a>
</header>
