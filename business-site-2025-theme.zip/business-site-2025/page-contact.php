<?php
/* Template Name: Contact */
get_header(); ?>
<div class="section">
<h2>Contact Us</h2>
<?php echo do_shortcode('[contact-form-7 id="123"]'); ?>
<h3>Our Location</h3>
<iframe src="https://www.google.com/maps/embed?pb=!1m18"
width="100%" height="300" style="border:0;" loading="lazy"></iframe>
</div>
<?php get_footer(); ?>
