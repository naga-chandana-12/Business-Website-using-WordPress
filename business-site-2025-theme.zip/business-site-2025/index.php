<?php get_header(); ?>
<div class="section">
<h1>Welcome to Our Business</h1>
<p>Professional digital solutions for your growth.</p>
</div>
<?php get_footer(); ?>
