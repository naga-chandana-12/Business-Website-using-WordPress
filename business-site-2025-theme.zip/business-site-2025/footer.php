<footer>
<p>© 2025 Business Website. All Rights Reserved.</p>
</footer>
<?php wp_footer(); ?>
</body>
</html>
